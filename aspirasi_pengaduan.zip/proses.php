<?php
session_start();
include 'koneksi.php';

if(isset($_POST['username'])){
    $u = $_POST['username'];
    if($u == 'admin'){
        header("Location: admin_login.php");
        exit;
    }
    $q = mysqli_query($conn,"SELECT * FROM users WHERE username='$u'");
    $d = mysqli_fetch_assoc($q);
    if($d){
        $_SESSION['user'] = $d;
        header("Location: dashboard.php");
    } else {
        echo "NIS tidak ditemukan";
    }
}

if(isset($_POST['login_admin'])){
    if($_POST['user']=='admin' && $_POST['pass']=='admin123'){
        $_SESSION['admin']=true;
        header("Location: admin.php");
    } else {
        echo "Login gagal";
    }
}

if(isset($_POST['kirim'])){
    $judul = $_POST['judul'];
    $isi = $_POST['isi'];
    $uid = $_SESSION['user']['id'];

    $foto = '';
    if($_FILES['foto']['name']!=''){
        $foto = $_FILES['foto']['name'];
        move_uploaded_file($_FILES['foto']['tmp_name'], "uploads/".$foto);
    }

    mysqli_query($conn,"INSERT INTO laporan (user_id,judul,isi,foto) 
    VALUES ('$uid','$judul','$isi','$foto')");

    header("Location: dashboard.php");
}

if(isset($_POST['balas'])){
    $id = $_POST['id'];
    $isi = $_POST['isi'];

    mysqli_query($conn,"INSERT INTO tanggapan (laporan_id,isi) VALUES ('$id','$isi')");
    mysqli_query($conn,"UPDATE laporan SET status='Selesai' WHERE id='$id'");

    header("Location: admin.php");
}

if(isset($_GET['hapus'])){
    mysqli_query($conn,"DELETE FROM laporan WHERE id=".$_GET['hapus']);
    header("Location: admin.php");
}
?>