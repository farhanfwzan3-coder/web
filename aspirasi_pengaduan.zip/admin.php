<?php
session_start();
if(!isset($_SESSION['admin'])) header("Location:index.php");
include 'koneksi.php';
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<div class="container mt-4">
<h3>Admin Panel</h3>
<a href="logout.php" class="btn btn-danger btn-sm mb-3">Logout</a>
<?php
$total=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM laporan"));
$selesai=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM laporan WHERE status='Selesai'"));
?>
<div class="row mb-3">
<div class="col"><div class="card p-3">Total: <?= $total ?></div></div>
<div class="col"><div class="card p-3">Selesai: <?= $selesai ?></div></div>
</div>
<?php
$q=mysqli_query($conn,"SELECT * FROM laporan");
while($d=mysqli_fetch_assoc($q)){
?>
<div class="card p-3 mb-2">
<b><?= $d['judul']; ?></b><br>
<?= $d['isi']; ?><br>
<?php if($d['foto']){ ?>
<img src="uploads/<?= $d['foto']; ?>" width="120">
<?php } ?>
<form method="POST" action="proses.php">
<input type="hidden" name="id" value="<?= $d['id']; ?>">
<textarea name="isi" class="form-control mb-2" placeholder="Balas"></textarea>
<button name="balas" class="btn btn-success btn-sm">Balas</button>
</form>
<a href="proses.php?hapus=<?= $d['id']; ?>" class="btn btn-danger btn-sm mt-2">Hapus</a>
</div>
<?php } ?>
</div>