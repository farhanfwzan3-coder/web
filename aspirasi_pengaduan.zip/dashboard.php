<?php
session_start();
if(!isset($_SESSION['user'])) header("Location:index.php");
include 'koneksi.php';
$user=$_SESSION['user'];
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<div class="container mt-4">
<h4>Halo, <?= $user['nama']; ?></h4>
<a href="logout.php" class="btn btn-danger btn-sm mb-3">Logout</a>
<div class="card p-3 mb-4">
<h5>Kirim Laporan</h5>
<form method="POST" action="proses.php" enctype="multipart/form-data">
<input type="text" name="judul" class="form-control mb-2" placeholder="Judul" required>
<textarea name="isi" class="form-control mb-2" placeholder="Isi laporan" required></textarea>
<input type="file" name="foto" class="form-control mb-2">
<button name="kirim" class="btn btn-primary">Kirim</button>
</form>
</div>
<h5>Riwayat</h5>
<?php
$q=mysqli_query($conn,"SELECT * FROM laporan WHERE user_id=".$user['id']);
while($d=mysqli_fetch_assoc($q)){
?>
<div class="card p-2 mb-2">
<b><?= $d['judul']; ?></b><br>
Status:
<span class="badge bg-<?=
$d['status']=='Selesai'?'success':
($d['status']=='Diproses'?'warning':'secondary')
?>">
<?= $d['status']; ?>
</span>
</div>
<?php } ?>
</div>