<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center vh-100">
<form method="POST" action="proses.php" class="card p-4 shadow" style="width:320px;">
<h4 class="text-center mb-3">Aspirasi Pengaduan</h4>
<input type="text" name="username" class="form-control mb-3" placeholder="NIS / Username" required>
<button class="btn btn-primary w-100">Masuk</button>
</form>
</body>
</html>