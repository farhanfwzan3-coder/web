<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title>Login Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center vh-100">
<form method="POST" action="proses.php" class="card p-4 shadow" style="width:320px;">
<h4 class="text-center mb-3">Login Admin</h4>
<input type="text" name="user" class="form-control mb-2" placeholder="Username" required>
<input type="password" name="pass" class="form-control mb-3" placeholder="Password" required>
<button name="login_admin" class="btn btn-primary w-100">Masuk</button>
</form>
</body>
</html>