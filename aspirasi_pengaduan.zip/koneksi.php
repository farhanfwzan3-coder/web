<?php
$conn = mysqli_connect("localhost","root","","aspirasi_pengaduan");
?>